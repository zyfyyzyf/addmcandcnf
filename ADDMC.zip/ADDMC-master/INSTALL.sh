mkdir -p build && cd build && cmake .. && make -f Makefile && cp addmc ..
