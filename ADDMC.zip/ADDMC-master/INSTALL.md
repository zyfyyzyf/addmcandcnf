# ADDMC installation (Linux)

## Prerequisites
### External
- autoconf 2.69
- cmake 2.8.9
- g++ 6.4.0
- make 3.82
- tar 1.30
- unzip 6.00
### Internal
In `lib.tar`:
- cudd 3.0.0
- cxxopts 2.1.2

## Command
```bash
./INSTALL.sh
```
