for ty in {0..9999} ; do
	./addmc < ../NeuroCNF/cnf_formula38/dimacs$ty.dimacs
done;                                                                